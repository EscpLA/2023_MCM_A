function dx = problem1_fun(t,x,n,h,L,k,alpha,N)

%问题1模型
  dx = zeros(n,1);
  for i=1:n
      r_i=(L(i)/(1+exp(-k(i)*h(t)))-L(i)/2);
      tmp=0;
      for kk=1:n
          if kk~=i
          tmp=tmp+alpha(i,kk)*x(kk)/N(kk);
          end
      end
      tmp_i=1-x(i)/N(i)-tmp;
      
      dx(i)=r_i*x(i)*tmp_i;
  end
  
end