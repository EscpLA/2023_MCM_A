clc; clear; close all;
year=2;%模拟年数
T=360*year;%方便起见，一年设置为360天，一个季度90天
dt=1;%时间间隔：1天
tlen=T/dt;
tspan = linspace(1, T, tlen);
n=4;%物种数量
%%

L=[0.3,0.2,0.2,0.25];%物种i的最大生长率
k=[1,2,10,4];%物种i的逻辑斯谛增长率
h=(1/tlen)*(1:tlen);%归一到0-1的降水量h(t)
r=zeros(n,tlen);
for i=1:n
    r(i,:)=L(i)./(1+exp(-k(i)*h))-L(i)/2;%生长率
end
figure
plot(h,r),xlabel('降水量'),ylabel('生长率'),
legend('specie1','specie2','specie3','specie4','Location','best')
beautiplot
exportgraphics(gcf,'img/多物种情况下生长率关于降水量的函数图像1.png','Resolution',300)



h=[0.01*ones(1,90),0.04*ones(1,90),0.03*ones(1,90),0.01*ones(1,90)];%设置一年内4个季度的降水量
h=repmat(h,1,year);%重复year年
alpha=[1,2,2,2;
    2,1,2,2;
    2,2,1,2;
    2,2,2,1];%物种k对物种i的竞争系数

N=[50,50,50,50];%物种i的最大容量
x0=[20,20,50,50];%物种i的初始容量



% Solving the differential system of equations with ode45
% [t,x] = ode45(@(t,x) problem1_fun(t,x,n,h,L,k,alpha,N), tspan, x0);

%改进欧拉法求解微分方程
[t,x] = ODE_ImprovedEuler( @(t,x) problem1_fun(t,x,n,h,L,k,alpha,N),tspan,dt,x0 );
figure
plot(t,x);xlabel('时间/天'),ylabel('植物数量')
legend('specie1','specie2','specie3','specie4','Location','best'),beautiplot
exportgraphics(gcf,'img/4种物种的数量生长曲线1.png','Resolution',300)

L=[1.6,1.4,1.0,0.5];
k=[1,2,5,4];
h=(1/tlen)*(1:tlen);
r=zeros(n,tlen);
for i=1:n
    r(i,:)=L(i)./(1+exp(-k(i)*h))-L(i)/2;
end
figure
plot(h,r),xlabel('降水量'),ylabel('生长率'),
legend('specie1','specie2','specie3','specie4','Location','best')
beautiplot
exportgraphics(gcf,'img/多物种情况下生长率关于降水量的函数图像2.png','Resolution',300)

h=[0.01*ones(1,90),0.04*ones(1,90),0.03*ones(1,90),0.01*ones(1,90)];
h=repmat(h,1,year);

alpha=[1,2,3,4;
    4,1,3,2;
    3,2,1,4;
    2,3,4,1];
N=[100,50,120,130];
x0=[10,20,30,40];

[t,x] = ODE_ImprovedEuler( @(t,x) problem1_fun(t,x,n,h,L,k,alpha,N),tspan,dt,x0 );
figure
plot(t,x);xlabel('时间/天'),ylabel('植物数量')
legend('specie1','specie2','specie3','specie4','Location','best'),beautiplot
exportgraphics(gcf,'img/4种物种的数量生长曲线2.png','Resolution',300)
