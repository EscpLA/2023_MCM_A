function y=fun(x,t)
wucha=huise(x,t(1));
wucha1=huise(wucha,t(2));
y=0;
for i=1:size(x,2)
    y=y+(wucha(i)-wucha1(i))^2;
end
y=-y;