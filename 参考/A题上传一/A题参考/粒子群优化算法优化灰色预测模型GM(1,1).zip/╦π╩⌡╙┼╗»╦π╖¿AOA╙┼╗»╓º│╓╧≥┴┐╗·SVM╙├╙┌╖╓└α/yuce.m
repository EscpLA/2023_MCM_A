function yuce(x,m)
% x=[2.874,3.278,3.337,3.390,3.679];%ԭʼ����
y=cumsum(x); %�ۼ�����
b=[];C=[];
%m=1/2;
for i=1:size(x,2)-1
    b(i)=-(m*y(i+1)+(1-m)*y(i));
    C(i)=x(i+1);
end

B=[b',ones(size(b,2),1)];

B

U=inv(B'*B)*B'*C'; 

A =U
t=U(2)/U(1);
for i=0:size(x,2)-1
    z(i+1)=(y(1)-t)*exp(-U(1)*i)+t;
end
xx=[x(1),diff(z)];
wucha=xx-x;
figure (2)
plot(x,'k-*')
disp('��ʵֵ')
x%��ʵֵ
hold on
plot(xx,'r-o')
disp('Ԥ��ֵ')
xx%Ԥ��ֵ
hold off
xlabel('')
ylabel('')
